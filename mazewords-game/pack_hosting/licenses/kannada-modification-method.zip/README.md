# Kannada database modification method (ODbL 1.0, section 4.6(b))

Contains information from V. Krishna’s Alar Kannada–English dictionary.
Copyright V. Krishna. https://alar.ink/ ; https://github.com/alar-dict/data
License: https://opendatacommons.org/licenses/odbl/1-0/

This archive provides the complete method used to produce the modified candidate database for Kannada revision 1, instead of redistributing its word list. No additional dictionary contents are added. The puzzle database remains downloadable at https://mazewords-packs.web.app/packs/kn/1.json .

Reproduction (Python 3.12 with PyYAML 6.0.3):
1. Extract this archive into an empty directory.
2. Download the exact URL in sources/source-lock.json to sources/alar.yml.
3. Install PyYAML==6.0.3 in a Python virtual environment.
4. Run: python tools/import-kannada-pilot.py --source-dir sources
5. Read tools/languages/kn-pilot.json. The importer verifies the upstream SHA-256 before transforming the data.

The importer contains the entire normalization, exclusion, deduplication and target-selection algorithm. The generated database is licensed under ODbL 1.0. The included importer may be used, copied and modified freely for reproducing this database.
