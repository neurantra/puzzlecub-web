#!/usr/bin/env python3
"""Import Alar alone for Kannada; keep its ODbL database separate from CC BY-SA corpora.
Requires PyYAML==6.0.3. The input and license are pinned by the source lock.
"""
import argparse,hashlib,json,pathlib,re,unicodedata,yaml
p=argparse.ArgumentParser();p.add_argument('--source-dir',type=pathlib.Path,required=True);a=p.parse_args()
r=pathlib.Path(__file__).resolve().parents[1];src=a.source_dir
lock=json.loads((src/'source-lock.json').read_text());item=next(i for i in lock if i['language']=='kn' and i['file']=='alar.yml')
raw=(src/item['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==item['sha256']
entries=yaml.load(raw,Loader=getattr(yaml,'CSafeLoader',yaml.SafeLoader))
words={};blocked=set();excluded=0
unsuitable=re.compile(r'\b(vulgar|obscene|derogatory|archaic|obsolete|penis|vagina|vulva|clitoris|testicle|pornograph\w*|sexual intercourse|copulat\w*|fuck\w*)\b',re.I)
for e in entries:
 w=unicodedata.normalize('NFC',str(e.get('entry','')).strip())
 if not re.fullmatch('[\u0c80-\u0cff]+',w) or len(w)>45:continue
 defs=e.get('defs') or []
 description=str(e.get('info',''))+' '+' '.join(str(d.get('entry','')) for d in defs)
 if unsuitable.search(description):blocked.add(w);excluded+=1;continue
 if not any(d.get('type') in ['noun','verb','adjective','adverb','pronoun','interjection','conjunction'] for d in defs):continue
 words.setdefault(w,str(e['id']))
accepted=sorted(set(words)-blocked)
# No frequency corpus is available. Balanced deterministic sampling avoids alphabet bias.
targets=sorted(sorted((w for w in accepted if len(w)<=24),key=lambda w:hashlib.sha256(w.encode()).hexdigest())[:24000])
out={'language':'kn','name':'ಕನ್ನಡ · Kannada','reviewStatus':'pilot-unreviewed','license':'ODbL-1.0','source':'V. Krishna’s Alar Kannada dictionary; normalized, filtered headwords, no frequency ranking. Familiarity/native review pending.','sources':[item],'importPolicy':{'frequencyAvailable':False,'targetSampling':'SHA-256 order, at most 24000 headwords up to 24 code points; balanced across the alphabet','excludedMetadata':'Unsupported scripts, multiword entries, unsuitable and obsolete definition markers'},'words':accepted,'commonWords':targets,'frequency':{},'sourceWords':{w:w for w in accepted},'sourceIds':{w:words[w] for w in accepted},'importStats':{'sourceEntries':len(entries),'excludedMetadata':excluded}}
(r/'tools/languages/kn-pilot.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('Kannada Alar',len(accepted),'dictionary entries,',len(targets),'target candidates',flush=True)
